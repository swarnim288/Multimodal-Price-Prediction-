# Data

Raw data is **not committed** to this repository (see [`.gitignore`](../.gitignore)) — catalog text, image URLs, and prices for roughly 75,000 grocery-product listings, drawn from a large e-commerce product catalog. This file documents the expected layout, schema, and how the pipeline expects to find it.

## Expected layout

```
data/
├── README.md              <- this file (committed)
├── sample/
│   └── train_sample.csv   <- 200-row preview, seed 42 (committed)
├── dataset/
│   └── train.csv          <- full training data (NOT committed — place your own copy here)
└── Train_Images/
    ├── 51mo8htwTHL.jpg    <- images named by the basename of `image_link` (NOT committed)
    └── ...
```

`config/config.yaml` points a single `data_root` setting at this directory (`data/` by default); `dataset/train.csv` and `Train_Images/` are read from underneath it.

## Schema (`dataset/train.csv`)

| Column | Type | Description |
|---|---|---|
| `sample_id` | int | unique row identifier |
| `catalog_content` | str | semi-structured text: an `Item Name: ...` line, zero or more `Bullet Point N: ...` lines, a `Value: <float>` line, a `Unit: <str>` line |
| `image_link` | str (URL) | URL to the product's primary image |
| `price` | float | target variable |

Example `catalog_content` (line breaks preserved):

```
Item Name: <product name>, <size> (Pack of <n>)
Bullet Point 1: <marketing copy>
Bullet Point 2: <marketing copy>
Value: 32.0
Unit: Ounce
```

Not every row has bullet points, and `Value`/`Unit` free-text is noisy (case variants, occasional missing-value sentinels) — see [`notebooks/01_eda.ipynb`](../notebooks/01_eda.ipynb) for the full breakdown.

## Obtaining the data

This repository does not redistribute the dataset. To reproduce a full run:

1. Place `train.csv` at `data/dataset/train.csv`, matching the schema above.
2. Download each row's image from its `image_link` URL into `data/Train_Images/`, keeping the URL's basename as the filename (e.g. `.../51mo8htwTHL.jpg` → `Train_Images/51mo8htwTHL.jpg`) — the pipeline entry point (`scripts/run_pipeline.sh`) expects images already on disk before the embedding-extraction stage runs.

For smoke-testing without the full dataset, [`sample/train_sample.csv`](sample/train_sample.csv) is a 200-row random sample (`random_state=42`) of `train.csv`, committed directly to this repo.
